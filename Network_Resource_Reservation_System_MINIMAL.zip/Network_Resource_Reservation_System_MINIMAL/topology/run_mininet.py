"""Start the four-host Mininet testbed and its TCP reservation server."""

import os
import sys
import time
from functools import partial

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import CAPACITY_MBPS

from mininet.cli import CLI
from mininet.link import Link
from mininet.net import Mininet
from mininet.node import OVSSwitch, RemoteController
from mininet.topo import Topo

SERVER_SCRIPT = os.path.join(PROJECT_ROOT, "server.py")


class ReservationTopo(Topo):
    def build(self):
        switch = self.addSwitch("s1")
        hosts = [
            self.addHost("h1", ip="10.0.0.1/24"),
            self.addHost("h2", ip="10.0.0.2/24"),
            self.addHost("h3", ip="10.0.0.3/24"),
            self.addHost("h4", ip="10.0.0.4/24"),
        ]
        for host in hosts:
            self.addLink(host, switch)


def main():
    if os.geteuid() != 0:
        print("Run this script with sudo: sudo python3 topology/run_mininet.py")
        return 1

    topo = ReservationTopo()
    switch_factory = partial(OVSSwitch, protocols="OpenFlow13")
    net = Mininet(
        topo=topo,
        controller=None,
        switch=switch_factory,
        link=Link,
        autoSetMacs=True,
        build=True,
    )
    net.addController("c0", controller=RemoteController, ip="127.0.0.1", port=6653)

    server_log = None
    server_process = None
    try:
        print("Starting Mininet topology...")
        net.start()
        time.sleep(2)
        print("Running initial connectivity test (pingAll)...")
        loss = net.pingAll()
        print(f"Initial packet loss: {loss:.1f}%")
        if loss > 0:
            print("WARNING: Some hosts could not reach each other. Check that the OS-Ken controller is running and connected.")

        h4 = net.get("h4")
        server_log = open("/tmp/nrr-reservation-server.log", "w", encoding="utf-8")
        server_process = h4.popen(
            [sys.executable, SERVER_SCRIPT, "--host", "0.0.0.0", "--port", "5000", "--capacity-mbps", str(CAPACITY_MBPS)],
            stdout=server_log,
            stderr=server_log,
        )
        time.sleep(1)
        if server_process.poll() is not None:
            print("Reservation server failed to start. Check /tmp/nrr-reservation-server.log")
            return 2

        print("\nReservation server is running on h4 (10.0.0.4:5000).")
        print("Use h1, h2 and h3 as client hosts from the Mininet CLI.")
        print(f"Client program: {os.path.join(PROJECT_ROOT, 'client.py')}")
        print("Type 'help' at the Mininet prompt for Mininet commands.\n")
        CLI(net)
    finally:
        if server_process is not None and server_process.poll() is None:
            server_process.terminate()
            try:
                server_process.wait(timeout=3)
            except Exception:
                server_process.kill()
        if server_log is not None:
            server_log.close()
        net.stop()
        print("Mininet stopped. Run 'sudo mn -c' if cleanup is needed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
