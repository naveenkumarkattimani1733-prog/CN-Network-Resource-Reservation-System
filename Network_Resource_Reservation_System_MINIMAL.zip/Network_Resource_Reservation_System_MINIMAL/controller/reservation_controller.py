"""OpenFlow 1.3 controller for the Network Resource Reservation System.

The app learns L2 forwarding paths and exposes a local Unix-domain control socket
used by the TCP reservation server. Accepted reservations become OVS QoS queues
and OpenFlow set_queue rules on the egress port connected to h4.
"""

import atexit
import json
import os
import socketserver
import subprocess
import threading

from os_ken.base import app_manager
from os_ken.controller import ofp_event
from os_ken.controller.handler import CONFIG_DISPATCHER, DEAD_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from os_ken.lib.packet import ether_types, ethernet, packet
from os_ken.ofproto import ofproto_v1_3

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import CLIENTS, SDN_SOCKET_PATH, SERVER_IP, SERVER_SWITCH_PORT, SERVER_SWITCH_PORT_NAME


class _ControlRequestHandler(socketserver.StreamRequestHandler):
    def handle(self):
        raw = self.rfile.readline(65536)
        try:
            request = json.loads(raw.decode("utf-8"))
            response = self.server.controller.handle_control_request(request)
        except Exception as exc:
            response = {"ok": False, "error": str(exc)}
        self.wfile.write((json.dumps(response) + "\n").encode("utf-8"))
        self.wfile.flush()


class _ThreadedUnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True


class ReservationController(app_manager.OSKenApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.datapaths = {}
        self._state_lock = threading.RLock()
        self.current_quotas = {ip: 0.0 for ip in CLIENTS}
        self._start_control_socket()
        atexit.register(self._remove_control_socket)
        self.logger.info("Reservation SDN controller started; waiting for OpenFlow 1.3 switches")

    def _start_control_socket(self):
        socket_dir = os.path.dirname(SDN_SOCKET_PATH)
        if socket_dir:
            os.makedirs(socket_dir, exist_ok=True)
        if os.path.exists(SDN_SOCKET_PATH):
            os.unlink(SDN_SOCKET_PATH)
        self._control_server = _ThreadedUnixServer(SDN_SOCKET_PATH, _ControlRequestHandler)
        self._control_server.controller = self
        os.chmod(SDN_SOCKET_PATH, 0o666)
        self._control_thread = threading.Thread(
            target=self._control_server.serve_forever,
            name="nrr-controller-control-socket",
            daemon=True,
        )
        self._control_thread.start()

    def _remove_control_socket(self):
        try:
            if hasattr(self, "_control_server"):
                self._control_server.shutdown()
                self._control_server.server_close()
        except Exception:
            pass
        try:
            if os.path.exists(SDN_SOCKET_PATH):
                os.unlink(SDN_SOCKET_PATH)
        except OSError:
            pass

    def handle_control_request(self, request: dict) -> dict:
        if not isinstance(request, dict) or request.get("action") != "APPLY":
            return {"ok": False, "error": "Unsupported controller command; expected APPLY."}

        try:
            capacity_mbps = float(request.get("capacity_mbps", 0))
            if capacity_mbps <= 0:
                raise ValueError("capacity_mbps must be greater than zero")
            supplied = request.get("quotas", {})
            if not isinstance(supplied, dict):
                raise ValueError("quotas must be a JSON object")
            quotas = {ip: float(supplied.get(ip, 0.0)) for ip in CLIENTS}
            if any(value < 0 for value in quotas.values()):
                raise ValueError("Quota values cannot be negative")
            if sum(quotas.values()) > capacity_mbps + 1e-6:
                raise ValueError("Sum of guaranteed quotas exceeds link capacity")
        except (TypeError, ValueError) as exc:
            return {"ok": False, "error": str(exc)}

        with self._state_lock:
            datapaths = list(self.datapaths.values())
            if not datapaths:
                return {"ok": False, "error": "No OpenFlow switch is connected to the controller yet."}
            datapath = datapaths[0]
            try:
                self._configure_ovs_qos(capacity_mbps, quotas)
                self._install_reservation_flows(datapath, quotas)
            except Exception as exc:
                self.logger.exception("Failed to apply reservation policy")
                return {"ok": False, "error": str(exc)}
            self.current_quotas = quotas
            self.logger.info("Applied bandwidth reservations: %s", quotas)
            return {"ok": True, "message": "QoS queues and OpenFlow reservation rules updated.", "quotas": quotas}

    def _configure_ovs_qos(self, capacity_mbps: float, quotas: dict):
        capacity_bps = int(capacity_mbps * 1_000_000)
        clear_cmd = ["ovs-vsctl", "--if-exists", "clear", "Port", SERVER_SWITCH_PORT_NAME, "qos"]
        subprocess.run(clear_cmd, check=True, capture_output=True, text=True, timeout=10)

        cmd = ["ovs-vsctl", "--"]
        queue_aliases = []
        for queue_id in range(4):
            if queue_id == 0:
                rate_bps = capacity_bps
                min_rate = None
            else:
                client_ip = next(ip for ip, details in CLIENTS.items() if details["queue_id"] == queue_id)
                quota = float(quotas.get(client_ip, 0.0))
                rate_bps = int(quota * 1_000_000) if quota > 0 else capacity_bps
                min_rate = int(quota * 1_000_000) if quota > 0 else None

            alias = f"@q{queue_id}"
            queue_aliases.append(f"queues:{queue_id}={alias}")
            cmd.extend(["--id=" + alias, "create", "Queue"])
            if min_rate is not None:
                cmd.append(f"other-config:min-rate={min_rate}")
            cmd.append(f"other-config:max-rate={rate_bps}")
            cmd.append("--")

        cmd.extend([
            "--id=@nrr_qos", "create", "QoS",
            "type=linux-htb",
            f"other-config:max-rate={capacity_bps}",
            *queue_aliases,
            "--", "set", "Port", SERVER_SWITCH_PORT_NAME, "qos=@nrr_qos",
        ])
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=15)

    def _install_reservation_flows(self, datapath, quotas: dict):
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        for client_ip, details in CLIENTS.items():
            queue_id = details["queue_id"] if float(quotas.get(client_ip, 0.0)) > 0 else 0
            match = parser.OFPMatch(
                eth_type=ether_types.ETH_TYPE_IP,
                ipv4_src=client_ip,
                ipv4_dst=SERVER_IP,
            )
            actions = [
                parser.OFPActionSetQueue(queue_id),
                parser.OFPActionOutput(SERVER_SWITCH_PORT),
            ]
            instructions = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
            flow_mod = parser.OFPFlowMod(
                datapath=datapath,
                cookie=0x4E525200 + queue_id,
                priority=250,
                match=match,
                instructions=instructions,
            )
            datapath.send_msg(flow_mod)

        datapath.send_msg(parser.OFPBarrierRequest(datapath))

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def _state_change_handler(self, ev):
        datapath = ev.datapath
        with self._state_lock:
            if ev.state == MAIN_DISPATCHER:
                self.datapaths[datapath.id] = datapath
            elif ev.state == DEAD_DISPATCHER:
                self.datapaths.pop(datapath.id, None)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def _switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        with self._state_lock:
            self.datapaths[datapath.id] = datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        instructions = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        datapath.send_msg(parser.OFPFlowMod(
            datapath=datapath,
            priority=0,
            match=match,
            instructions=instructions,
        ))
        self.logger.info("Switch %s connected; installed table-miss rule", datapath.id)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match["in_port"]

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if eth is None or eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][eth.src] = in_port
        out_port = self.mac_to_port[dpid].get(eth.dst, ofproto.OFPP_FLOOD)
        actions = [parser.OFPActionOutput(out_port)]

        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(in_port=in_port, eth_dst=eth.dst)
            instructions = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
            datapath.send_msg(parser.OFPFlowMod(
                datapath=datapath,
                priority=10,
                match=match,
                instructions=instructions,
                idle_timeout=60,
            ))

        data = None if msg.buffer_id != ofproto.OFP_NO_BUFFER else msg.data
        packet_out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=msg.buffer_id,
            in_port=in_port,
            actions=actions,
            data=data,
        )
        datapath.send_msg(packet_out)
