#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

PY_MINOR="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
PY_OK="$(python3 -c 'import sys; print(int(sys.version_info >= (3, 10)))')"
if [[ "$PY_OK" != "1" ]]; then
  echo "Python 3.10 or newer is required for the current OS-Ken package."
  echo "Use an Ubuntu VM with Python 3.10+ (Ubuntu 22.04 is a suitable baseline)."
  echo "Detected Python: $PY_MINOR"
  exit 1
fi

echo "Installing Mininet, Open vSwitch and traffic-testing tools..."
sudo apt-get update
sudo apt-get install -y mininet openvswitch-switch iproute2 iperf3 python3-venv python3-pip
sudo systemctl enable --now openvswitch-switch

if [[ ! -d "$PROJECT_ROOT/.venv" ]]; then
  python3 -m venv "$PROJECT_ROOT/.venv"
fi

"$PROJECT_ROOT/.venv/bin/python" -m pip install --upgrade pip
"$PROJECT_ROOT/.venv/bin/python" -m pip install -r "$PROJECT_ROOT/requirements.txt"

printf '\nInstallation checks:\n'
mn --version
ovs-vsctl --version | head -n 1
"$PROJECT_ROOT/.venv/bin/osken-manager" --help >/dev/null
printf '\nSetup completed. Start the SDN controller and Mininet in two terminals.\n'
