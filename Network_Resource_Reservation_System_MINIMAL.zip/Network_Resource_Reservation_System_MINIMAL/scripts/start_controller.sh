#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONTROLLER="$PROJECT_ROOT/.venv/bin/osken-manager"
APP="$PROJECT_ROOT/controller/reservation_controller.py"

if [[ ! -x "$CONTROLLER" ]]; then
  echo "OS-Ken is not installed. Run: ./scripts/setup_ubuntu.sh"
  exit 1
fi

cd "$PROJECT_ROOT"
echo "Starting OS-Ken on OpenFlow TCP port 6653..."
echo "Keep this terminal open while running Mininet."
sudo "$CONTROLLER" --ofp-tcp-listen-port 6653 "$APP"
