#!/usr/bin/env bash
set -euo pipefail
sudo mn -c
sudo rm -f /tmp/nrr_sdn_controller.sock /tmp/nrr-reservation-server.log
echo "Mininet and temporary project files cleaned. Stop the controller before running this script."
