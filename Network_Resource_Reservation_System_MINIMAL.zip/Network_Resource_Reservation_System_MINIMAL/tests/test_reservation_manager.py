import threading
import unittest
from datetime import datetime, timedelta, timezone

from reservation_manager import ReservationManager


class FakeController:
    def __init__(self, fail=False):
        self.fail = fail
        self.last_quotas = None
        self.calls = 0

    def apply_quotas(self, quotas, capacity_mbps):
        self.calls += 1
        if self.fail:
            raise RuntimeError("simulated controller failure")
        self.last_quotas = dict(quotas)
        return {"ok": True}


class ReservationManagerTests(unittest.TestCase):
    def setUp(self):
        self.controller = FakeController()
        self.manager = ReservationManager(self.controller, capacity_mbps=100)

    def test_accepts_reservation_and_updates_quota(self):
        result = self.manager.reserve("10.0.0.1", 40, 60)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["resource"]["reserved_mbps"], 40)
        self.assertEqual(self.controller.last_quotas["10.0.0.1"], 40)

    def test_rejects_overbooking(self):
        self.assertTrue(self.manager.reserve("10.0.0.1", 70, 60)["accepted"])
        rejected = self.manager.reserve("10.0.0.2", 40, 60)
        self.assertFalse(rejected["accepted"])
        self.assertEqual(self.manager.status()["resource"]["reserved_mbps"], 70)

    def test_release_returns_capacity(self):
        accepted = self.manager.reserve("10.0.0.2", 35, 60)
        reservation_id = accepted["reservation"]["reservation_id"]
        released = self.manager.release("10.0.0.2", reservation_id)
        self.assertTrue(released["released"])
        self.assertEqual(released["resource"]["available_mbps"], 100)

    def test_expiry_returns_capacity(self):
        accepted = self.manager.reserve("10.0.0.3", 25, 60)
        reservation_id = accepted["reservation"]["reservation_id"]
        with self.manager._lock:
            self.manager._active[reservation_id].expires_at = (
                datetime.now(timezone.utc) - timedelta(seconds=1)
            ).isoformat(timespec="seconds")
        expired = self.manager.expire()
        self.assertIn(reservation_id, expired)
        self.assertEqual(self.manager.status()["resource"]["available_mbps"], 100)

    def test_concurrent_requests_do_not_overbook(self):
        barrier = threading.Barrier(5)
        results = []
        result_lock = threading.Lock()

        def request(client_ip):
            barrier.wait()
            result = self.manager.reserve(client_ip, 30, 60)
            with result_lock:
                results.append(result)

        threads = [
            threading.Thread(target=request, args=(ip,))
            for ip in ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.1"]
        ]
        for thread in threads:
            thread.start()
        barrier.wait()
        for thread in threads:
            thread.join()

        accepted = [result for result in results if result["accepted"]]
        self.assertEqual(len(accepted), 3)
        self.assertLessEqual(self.manager.status()["resource"]["reserved_mbps"], 100)

    def test_controller_failure_rolls_back_reservation(self):
        broken_controller = FakeController(fail=True)
        manager = ReservationManager(broken_controller, capacity_mbps=100)
        result = manager.reserve("10.0.0.1", 20, 30)
        self.assertFalse(result["accepted"])
        self.assertEqual(manager.status()["resource"]["reserved_mbps"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
